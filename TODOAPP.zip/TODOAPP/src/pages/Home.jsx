import './Home.css'


const Home = () => {
  return (
    <div className='homeText'>
      <h2>Welcome to my Todo App of !</h2>
      <p>This is the home page.</p>
    </div>
  );
}

export default Home;
