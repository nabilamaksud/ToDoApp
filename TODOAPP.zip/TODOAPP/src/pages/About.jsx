import './About.css'
const About = () => {
  return (
    <div className='aboutText'>
      <h2>About Page</h2>
      <p>This is the about page of my Todo App.</p>
    </div>
  );
}

export default About;
